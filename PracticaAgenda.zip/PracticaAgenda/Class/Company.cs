﻿using System.Text;

namespace PracticaAgenda.Class
{
    public class Company : Contact
    {
        public Company()
        {
            sector = string.Empty;
        }

        private string sector;
        public string Sector { get => sector; set => sector = value; }

        private int employedNumber;
        public int EmployedNumber { get => employedNumber; set => employedNumber = value; }
        public override void Create()
        {
            base.Create();            
            Console.WriteLine("Sector: ");
            Sector = Console.ReadLine() ?? String.Empty;
            Console.WriteLine("Employed number: ");
            EmployedNumber = Convert.ToInt32(Console.ReadLine());
        }
        public override void SetValue(int property, object value)
        {
            base.SetValue(property, value);
            switch (property)
            {
                case 5:
                    Sector = value.ToString();                    
                    break;
                case 6:
                    EmployedNumber = Convert.ToInt32(value);
                    break;
            }
        }

        public override void EditOption()
        {
            base.EditOption();
            Console.WriteLine("5. Sector");
            Console.WriteLine("6. Employed number");
        }
        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append(base.ToString());
            builder.AppendLine("Sector: " + Sector);
            builder.AppendLine("Employed number: " + EmployedNumber);

            return builder.ToString();
        }
    }
}
