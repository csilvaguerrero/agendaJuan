﻿using System.Text;

namespace PracticaAgenda.Class
{
    public abstract class Contact
    {
        public Contact()
        {
            name =  string.Empty;
            lastName = string.Empty;
            id = string.Empty;
            telephoneNumber = string.Empty;
        }

        private string name;
        public string Name { get => name; set => name = value; }

        private string lastName;
        public string LastName { get => lastName; set => lastName = value; }
        private string id;
        public string Id { get => id; set => id = value; }
        private string telephoneNumber;
        public string TelephoneNumber { get => telephoneNumber; set => telephoneNumber = value; }
        public virtual void EditOption() 
        {
            Console.WriteLine("1. Name");
            Console.WriteLine("2. Last name");
            Console.WriteLine("3. Identifier");
            Console.WriteLine("4. Telephone");
        }
        public virtual void SetValue(int property, object value)
        {
            switch(property)
            {
                case 1:
                    Name = value.ToString();
                    break;
                case 2:
                    LastName = value.ToString();
                    break;
                case 3:
                    Id = value.ToString();
                    break;
                case 4:
                    TelephoneNumber = value.ToString();
                    break;
            }
        }
        public virtual void Create() 
        {
            Console.WriteLine("Name: ");
            Name = Console.ReadLine() ?? String.Empty;
            Console.WriteLine("Last name: ");
            LastName = Console.ReadLine() ?? String.Empty;
            Console.WriteLine("Identifier: ");
            Id = Console.ReadLine() ?? String.Empty;
            Console.WriteLine("Telephone: ");
            TelephoneNumber = Console.ReadLine() ?? String.Empty;
        }
        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("Name: " + Name);
            builder.AppendLine("Last name: " + LastName);
            builder.AppendLine("Identifier: " + Id);
            builder.AppendLine("Telephone: " + TelephoneNumber);

            return builder.ToString();
        }
    }
}
