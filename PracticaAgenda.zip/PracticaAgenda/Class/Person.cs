﻿using System.Text;

namespace PracticaAgenda.Class
{
    public class Person : Contact 
    {
        public Person() 
        { 
            gender =  string.Empty;
        }

        private string gender;
        public string Gender { get => gender; set => gender = value; }

        private int age;
        public int Age { get => age; set => age = value; }
        public override void Create()
        {
            base.Create();
            Console.WriteLine("Age: ");
            Age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Gender: ");
            Gender = Console.ReadLine() ?? String.Empty;
        }
        public override void EditOption()
        {
            base.EditOption();
            Console.WriteLine("5. Age");
            Console.WriteLine("6. Gender");
        }

        public override void SetValue(int property, object value)
        {
            base.SetValue(property, value);
            switch (property)
            {
                case 5:
                    Age = Convert.ToInt32(value);
                    break;
                case 6:
                    Gender = value.ToString();
                    break;
            }
        }

        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append(base.ToString());
            builder.AppendLine("Age: " + Age);
            builder.AppendLine("Gender: " + Gender);    
            
            return builder.ToString();
        }
    }
}
