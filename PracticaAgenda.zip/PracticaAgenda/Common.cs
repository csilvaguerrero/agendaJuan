﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PracticaAgenda.Class;

namespace PracticaAgenda
{
    public static class Common
    {
        public static void Test(ref int x)
        {
            x = 20;
        }

        public static void Test(string x)
        {
            x = "New Value";
        }

        public static void Create(Contact contact)
        {
            string type = contact.GetType().Name;
            Console.WriteLine("------ Vamos a crear un objeto " + type + " --------- ");
            contact.Create();
        }

        public static void Edit(Contact contact)
        {
            string type = contact.GetType().Name;
            Console.WriteLine("------ Vamos a editar un objeto " + type + " --------- ");
            Console.WriteLine("Seleccione una opción:");
            contact.EditOption();
            int option = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Introduzca valor: ");
            object value = Console.ReadLine();
            contact.SetValue(option, value);
        }

        public static void ListContacts(List<Contact> list)
        {
            Console.WriteLine("----------------- LISTADO DE CONTACTOS --------------------");
            foreach (Contact c in list)
            {                
                Console.WriteLine(c.ToString());
                Console.WriteLine("------------------------------------------------");
            }
        }
    }
}
