﻿// See https://aka.ms/new-console-template for more information
using PracticaAgenda;
using PracticaAgenda.Class;

List<Contact> contacts = new List<Contact>();   

Contact person = new Person();
Contact company = new Company();

contacts.Add(person);
contacts.Add(company);

Common.Create(person);
Common.Create(company);

Common.ListContacts(contacts);

Common.Edit(person);
Common.Edit(company);

Common.ListContacts(contacts);

Console.ReadLine();